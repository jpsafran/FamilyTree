/* ui.js
   ----------
   Functions to show/hide modals, handle context menu actions,
   plus "openModal"/"closeModal" utilities.
*/

/** Show context menu at the pointer */
function showContextMenu(event, member) {
    window.currentContextMember = member; // store globally for reference
    const menu = document.getElementById("context-menu");
    menu.style.left = event.clientX + "px";
    menu.style.top = event.clientY + "px";
    menu.style.display = "block";
  }
  
  /** Hide the context menu */
  function hideContextMenu() {
    document.getElementById("context-menu").style.display = "none";
  }
  
  /** Open a modal by ID */
  function openModal(id) {
    document.getElementById(id).style.display = "block";
  }
  
  /** Close a modal by ID */
  function closeModal(id) {
    document.getElementById(id).style.display = "none";
  }
  
  /** Show "View Info" modal */
  function showInfoModal(member) {
    document.getElementById("info-name").textContent = member.name;
    document.getElementById("info-birth").textContent = member.birth
      ? "Born: " + member.birth
      : "";
    document.getElementById("info-death").textContent = member.death
      ? "Died: " + member.death
      : "";
    document.getElementById("info-age").textContent =
      "Age: " + calculateAge(member.birth, member.death);
    document.getElementById("info-details").textContent = member.details || "";
    document.getElementById("info-image").src =
      member.image || "https://via.placeholder.com/80";
  
    // Edit button
    document.getElementById("info-edit-btn").onclick = () => {
      closeModal("info-modal");
      showEditModal(member);
    };
    // Delete button
    document.getElementById("info-delete-btn").onclick = () => {
      if (confirm("Delete this member?")) {
        familyMembers = familyMembers.filter((m) => m.id !== member.id);
        relationships = relationships.filter(
          (r) => r.from !== member.id && r.to !== member.id
        );
        saveData();
        render();
        closeModal("info-modal");
      }
    };
  
    openModal("info-modal");
  }
  
  /** Show Add/Edit Member modal */
  function showEditModal(member) {
    const title = document.getElementById("edit-modal-title");
    const nameInput = document.getElementById("edit-name");
    const birthInput = document.getElementById("edit-birth");
    const deathInput = document.getElementById("edit-death");
    const detailsInput = document.getElementById("edit-details");
    const imageInput = document.getElementById("edit-image");
  
    if (member) {
      // Editing
      title.textContent = "Edit Member";
      nameInput.value = member.name;
      birthInput.value = member.birth || "";
      deathInput.value = member.death || "";
      detailsInput.value = member.details || "";
      imageInput.value = member.image || "";
    } else {
      // Adding
      title.textContent = "Add Member";
      nameInput.value = "";
      birthInput.value = "";
      deathInput.value = "";
      detailsInput.value = "";
      imageInput.value = "";
    }
  
    document.getElementById("edit-save-btn").onclick = () => {
      const newName = nameInput.value.trim();
      if (!newName) {
        alert("Name is required!");
        return;
      }
      if (member) {
        // Update existing
        member.name = newName;
        member.birth = birthInput.value;
        member.death = deathInput.value;
        member.details = detailsInput.value;
        member.image = imageInput.value;
      } else {
        // Create new
        const newMember = {
          id: generateId(),
          name: newName,
          birth: birthInput.value,
          death: deathInput.value,
          details: detailsInput.value,
          image: imageInput.value,
          x: 400,
          y: 300,
        };
        familyMembers.push(newMember);
      }
      saveData();
      closeModal("edit-modal");
      render();
    };
  
    openModal("edit-modal");
  }
  
  /** Show Relationship modal (Add) */
  function showRelationshipModal(member) {
    document.getElementById("rel-chosen").textContent =
      "Adding relationship for: " + member.name;
  
    const targetSelect = document.getElementById("rel-target");
    const typeSelect = document.getElementById("rel-type");
  
    targetSelect.innerHTML = "";
    familyMembers.forEach((m) => {
      if (m.id !== member.id) {
        const opt = document.createElement("option");
        opt.value = m.id;
        opt.textContent = m.name;
        targetSelect.appendChild(opt);
      }
    });
    typeSelect.value = "parent";
  
    document.getElementById("rel-save-btn").onclick = () => {
      const targetId = parseInt(targetSelect.value, 10);
      const chosenType = typeSelect.value;
      // Remove duplicates
      relationships = relationships.filter(
        (r) =>
          !(
            (r.from === member.id && r.to === targetId) ||
            (r.from === targetId && r.to === member.id)
          )
      );
      relationships.push({ from: member.id, to: targetId, type: chosenType });
      saveData();
      closeModal("rel-modal");
      render();
    };
  
    openModal("rel-modal");
  }
  
  /** Show "Manage Relationships" modal */
  function showManageRelationshipsModal(member) {
    const title = document.getElementById("manage-rel-title");
    title.textContent = "Manage Relationships for " + member.name;
  
    const list = document.getElementById("manage-rel-list");
    list.innerHTML = "";
  
    // Get all relationships involving this member
    const memberRels = relationships.filter(
      (r) => r.from === member.id || r.to === member.id
    );
  
    memberRels.forEach((rel) => {
      const li = document.createElement("li");
      const otherId = rel.from === member.id ? rel.to : rel.from;
      const otherMember = familyMembers.find((m) => m.id === otherId);
      const relText = `${rel.type} → ${otherMember?.name || "Unknown"}`;
      li.textContent = relText;
  
      // Delete button
      const delBtn = document.createElement("button");
      delBtn.textContent = "X";
      delBtn.classList.add("rel-delete-btn");
      delBtn.onclick = () => {
        // Remove this relationship
        relationships = relationships.filter((r) => r !== rel);
        saveData();
        render();
        // Refresh this modal so the updated list is shown
        showManageRelationshipsModal(member);
      };
  
      li.appendChild(delBtn);
      list.appendChild(li);
    });
  
    openModal("manage-rel-modal");
  }
  