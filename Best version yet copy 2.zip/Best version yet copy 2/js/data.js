/* data.js
   ----------
   Manages loading/saving family data to localStorage,
   plus some helper functions (ID generation, age calculation).
*/

let familyMembers = [];
let relationships = [];

// Attempt to load from localStorage
try {
  familyMembers = JSON.parse(localStorage.getItem("familyMembers")) || [];
  relationships = JSON.parse(localStorage.getItem("relationships")) || [];
} catch (e) {
  familyMembers = [];
  relationships = [];
}

// If empty, add two dummy members
if (!familyMembers.length) {
  familyMembers.push({
    id: 1,
    name: "Alice",
    birth: "1970-01-01",
    death: "",
    details: "Enjoys gardening",
    image: "",
    x: 300,
    y: 300,
  });
  familyMembers.push({
    id: 2,
    name: "Bob",
    birth: "1965-05-05",
    death: "",
    details: "Likes fishing",
    image: "",
    x: 600,
    y: 400,
  });
  saveData();
}

/** Save to localStorage */
function saveData() {
  localStorage.setItem("familyMembers", JSON.stringify(familyMembers));
  localStorage.setItem("relationships", JSON.stringify(relationships));
}

/** Generate a new unique ID */
function generateId() {
  return familyMembers.length
    ? Math.max(...familyMembers.map((m) => m.id)) + 1
    : 1;
}

/** Calculate age or "N/A" */
function calculateAge(birth, death) {
  if (!birth) return "N/A";
  const b = new Date(birth);
  if (death) {
    const d = new Date(death);
    return d.getFullYear() - b.getFullYear() + " (at death)";
  }
  return new Date().getFullYear() - b.getFullYear();
}
