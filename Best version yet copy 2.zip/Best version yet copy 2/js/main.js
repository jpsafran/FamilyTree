/* main.js
   ----------
   Orchestrates the app:
   - D3 rendering & auto-center
   - Node dragging
   - Context menu actions
   - Toolbar (Add, Export, Import)
   - Initialization (initApp)
*/

document.addEventListener("DOMContentLoaded", initApp);

let zoom; // D3 zoom behavior
let currentContextMember = null; // also stored in window.currentContextMember

function initApp() {
  setupUI();
  setupZoom();
  render();
}

/* ---------- Rendering with D3 ---------- */
function render() {
  const svg = d3.select("#tree-svg");
  svg.selectAll("*").remove(); // clear old

  // Groups for lines and nodes
  const linesGroup = svg.append("g").attr("id", "lines-group");
  const nodesGroup = svg.append("g").attr("id", "nodes-group");

  // Draw lines
  relationships.forEach((rel) => {
    const fromM = familyMembers.find((m) => m.id === rel.from);
    const toM = familyMembers.find((m) => m.id === rel.to);
    if (!fromM || !toM) return;
    linesGroup
      .append("line")
      .attr("x1", fromM.x)
      .attr("y1", fromM.y)
      .attr("x2", toM.x)
      .attr("y2", toM.y)
      .attr("stroke", "#999")
      .attr("stroke-width", 2)
      .attr("stroke-dasharray", rel.type === "spouse" ? "4,2" : null);
  });

  // Draw nodes
  const nodes = nodesGroup.selectAll(".person-node").data(familyMembers, (d) => d.id);

  const nodeEnter = nodes
    .enter()
    .append("g")
    .attr("class", "person-node")
    .attr("transform", (d) => `translate(${d.x},${d.y})`)
    .call(
      d3.drag()
        .on("start", dragStarted)
        .on("drag", dragged)
        .on("end", dragEnded)
    );

  nodeEnter
    .append("circle")
    .attr("r", 30) // radius in CSS or here
    .attr("fill", "#3498db");

  nodeEnter
    .append("text")
    .attr("dy", ".35em")
    .text((d) => d.name);

  // Right-click => context menu
  nodeEnter.on("contextmenu", (event, d) => {
    event.preventDefault();
    event.stopPropagation();
    showContextMenu(event, d);
  });

  nodes.merge(nodeEnter).attr("transform", (d) => `translate(${d.x},${d.y})`);
  nodes.exit().remove();

  // Auto-center after drawing
  centerNodes();
}

/* ---------- Zoom & Pan ---------- */
function setupZoom() {
  const svg = d3.select("#tree-svg").attr("width", "100%").attr("height", "100%");
  zoom = d3
    .zoom()
    .scaleExtent([0.5, 2])
    .on("zoom", (event) => {
      svg.select("#lines-group").attr("transform", event.transform);
      svg.select("#nodes-group").attr("transform", event.transform);
    });
  svg.call(zoom);
}

/* Auto-center nodes by bounding box */
function centerNodes() {
  if (!familyMembers.length) return;
  const container = document.getElementById("tree-container");
  const width = container.clientWidth;
  const height = container.clientHeight;

  const minX = d3.min(familyMembers, (d) => d.x);
  const maxX = d3.max(familyMembers, (d) => d.x);
  const minY = d3.min(familyMembers, (d) => d.y);
  const maxY = d3.max(familyMembers, (d) => d.y);

  const nodesWidth = maxX - minX;
  const nodesHeight = maxY - minY;
  const margin = 100;
  const scale = Math.min(
    width / (nodesWidth + margin),
    height / (nodesHeight + margin)
  );
  const finalScale = isFinite(scale) && scale > 0 ? scale : 1;
  const offsetX = (width - nodesWidth * finalScale) / 2;
  const offsetY = (height - nodesHeight * finalScale) / 2;

  const transform = d3.zoomIdentity
    .translate(offsetX - minX * finalScale, offsetY - minY * finalScale)
    .scale(finalScale);

  d3.select("#tree-svg").call(zoom.transform, transform);
}

/* ---------- Dragging Nodes ---------- */
function dragStarted(event, d) {
  d3.select(this).raise().classed("active", true);
}

function dragged(event, d) {
  d.x = event.x;
  d.y = event.y;
  d3.select(this).attr("transform", `translate(${d.x},${d.y})`);
  updateLines();
}

function dragEnded(event, d) {
  d3.select(this).classed("active", false);
  saveData();
  updateLines();
}

function updateLines() {
  const linesGroup = d3.select("#lines-group");
  linesGroup.selectAll("*").remove();

  relationships.forEach((rel) => {
    const fromM = familyMembers.find((m) => m.id === rel.from);
    const toM = familyMembers.find((m) => m.id === rel.to);
    if (!fromM || !toM) return;
    linesGroup
      .append("line")
      .attr("x1", fromM.x)
      .attr("y1", fromM.y)
      .attr("x2", toM.x)
      .attr("y2", toM.y)
      .attr("stroke", "#999")
      .attr("stroke-width", 2)
      .attr("stroke-dasharray", rel.type === "spouse" ? "4,2" : null);
  });
}

/* ---------- Toolbar & UI ---------- */
function setupUI() {
  // Add Member
  document.getElementById("add-member-btn").onclick = () => {
    showEditModal(null);
  };
  // Export
  document.getElementById("export-btn").onclick = exportData;
  // Import
  document.getElementById("import-file").onchange = importData;
  // Search
  document.getElementById("search-input").addEventListener("input", function () {
    // Remove any console logs or text if you want no popups
    // (We simply do nothing here.)
  });

  // Close modals
  document.getElementById("info-close").onclick = () => closeModal("info-modal");
  document.getElementById("edit-close").onclick = () => closeModal("edit-modal");
  document.getElementById("rel-close").onclick = () => closeModal("rel-modal");
  document.getElementById("manage-rel-close").onclick = () =>
    closeModal("manage-rel-modal");

  // Hide context menu if clicking outside
  document.addEventListener("click", (e) => {
    if (!e.target.closest("#context-menu")) hideContextMenu();
  });
  // Hide context menu if right-click outside a node
  document
    .getElementById("tree-container")
    .addEventListener("contextmenu", (e) => {
      if (!e.target.closest(".person-node")) hideContextMenu();
    });

  setupContextMenuActions();
}

function setupContextMenuActions() {
  document.getElementById("ctx-view-info").onclick = () => {
    hideContextMenu();
    if (window.currentContextMember) showInfoModal(window.currentContextMember);
  };
  document.getElementById("ctx-edit-member").onclick = () => {
    hideContextMenu();
    if (window.currentContextMember) showEditModal(window.currentContextMember);
  };
  document.getElementById("ctx-add-relationship").onclick = () => {
    hideContextMenu();
    if (window.currentContextMember) {
      showRelationshipModal(window.currentContextMember);
    }
  };
  document.getElementById("ctx-manage-relationships").onclick = () => {
    hideContextMenu();
    if (window.currentContextMember) {
      showManageRelationshipsModal(window.currentContextMember);
    }
  };
  document.getElementById("ctx-delete-member").onclick = () => {
    hideContextMenu();
    if (window.currentContextMember && confirm("Delete this member?")) {
      familyMembers = familyMembers.filter(
        (m) => m.id !== window.currentContextMember.id
      );
      relationships = relationships.filter(
        (r) =>
          r.from !== window.currentContextMember.id &&
          r.to !== window.currentContextMember.id
      );
      saveData();
      render();
    }
  };
}

/* ---------- Import/Export ---------- */
function exportData() {
  const data = { familyMembers, relationships };
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "family_tree.json";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function importData(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const obj = JSON.parse(reader.result);
      familyMembers = obj.familyMembers || [];
      relationships = obj.relationships || [];
      saveData();
      // If you want zero popups, remove alerts
      // alert("Imported successfully!");
      render();
    } catch (err) {
      // alert("Invalid JSON file");
      // For no popups, just ignore or console.error
      console.error("Invalid JSON file:", err);
    }
  };
  reader.readAsText(file);
}
